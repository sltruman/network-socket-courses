//请求方式
//请求地址与请求参数
//同步或异步
//发送数据(get情况传Null)
function getData(method, url, mode, data) {
    return new Promise((reject, resolve) => {
        let ajax;
        if (window.XMLHttpRequest()) {
            ajax = new XMLHttpRequest()
        } else {
            ajax = new ActiveXObject('Microsoft.XMLHTTP')
        }
        ajax.onreadystatechange = function () {
            if (this.readyState == 4) {
                if (this.status == 200) {
                    //是否有这个密码 this.responseText
                    resolve(JSON.parse(this.responseText))
                } else {
                    reject('服务器繁忙')
                }
            }
        }
        ajax.opne(method, url, mode);
        ajax.send(data)
    })
}

export { getData }