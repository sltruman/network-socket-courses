//import * as module from './getData.js';
function window_innerTxt(dom, txt) {
    document.getElementById(dom).innerHTML = txt;
}
function set_p(id, tag, value) {
    let dom = document.getElementById(id);
    let dom_child = dom.getElementsByTagName(tag);
    for (let i = 0; i < dom_child.length; i++) {
        dom_child[i].style.height = value;
    }
}
function set_style(id,style,value){
    document.getElementById(id).style[style] = value;
}
function ux(Modal_left, RoomCode_value, menu_content_bottom, user_display_area_height, user_list_width) {
    set_style('Modal','left',Modal_left);
    set_style('menu_content','bottom',menu_content_bottom);
    set_style('user_display_area','height',user_display_area_height);
    set_style('user_list','width',user_list_width);
    document.getElementById('RoomCode').value = RoomCode_value
}
function input_focus(name,focus_color,blur_color,target_dom,target_dom_txt){
    document.getElementById(name).onfocus = function () {
        this.parentNode.style.borderColor = focus_color;
        window_innerTxt(target_dom, target_dom_txt);
    }
    document.getElementById(name).onblur = function () {
        this.parentNode.style.borderColor = blur_color;
    }
}
set_style('message_box','height',document.getElementById('play').offsetHeight*0.6+'px')
//界面弹幕函数
    //user:用户名
    //txt：文本内容（用户输入）
    //url：/请求路径？参数
function bullet_txt(user,txt,url){
    let target = document.getElementById('message_box');
    target.scrollTop = target.scrollHeight 
    let msg = document.createElement('p');
    let a = '';
    if(url) a="<a href="+url+">查看</a>";
    msg.innerHTML = user+"："+txt+a;
    msg.className = 'danmu';
    let msg_box = document.createElement('div');
    msg_box.appendChild(msg);
    target.appendChild(msg_box);
    //let left = document.body.offsetWidth;
    // msg.style.left =  left + 'px';
    // let time = setInterval(()=>{
    //     left-=10;
    //     msg.style.left =  left + 'px';
    //     if(left <= -(msg.offsetWidth)){
    //         clearInterval(time)
    //         msg_box.removeChild(msg);
    //     }
    // },100)
    //调用接口,传入文本
}
input_focus('RoomCode','rgb(77, 164, 245)','','RoomCode_tips','');
input_focus('bullet_input','rgb(77, 164, 245)','','bullet_tips','');
let bottom_menu_button = document.getElementById('bottom_menu').getElementsByTagName('button');
for (let i = 0; i < bottom_menu_button.length; i++) {
    bottom_menu_button[i].i = i;
    bottom_menu_button[i].onclick = function () {
        switch (this.i) {
            case 0:
                //点击创建会议按钮
                window_innerTxt('window_title', '创建会议')
                window_innerTxt('Modal_meeting_button', '创建会议')
                set_style('Modal','left','0px');
                //点击进入按钮
                document.getElementById('Modal_meeting_button').onclick = function () {
                    if (!document.getElementById('RoomCode').value) {
                        window_innerTxt('RoomCode_tips', '房间密码不能为空')
                    } else {
                        //创建房间后
                        //ux,最后一个参数说明，90为单个用户的宽度，用户的个数*90等于总长度
                        ux('', '', '-60px', '120px', 90 * 6 + 'px');
                        set_p('success_after_btn', 'p', '60px');
                        //显示房间信息
                        window_innerTxt('Room_info','我是房间信息')
                    }
                }
                break;
            case 1:
                //点击加入会议按钮
                window_innerTxt('window_title', '加入会议')
                window_innerTxt('Modal_meeting_button', '加入会议')
                set_style('Modal','left','0px');
                //点击进入按钮
                document.getElementById('Modal_meeting_button').onclick = function () {
                    if (!document.getElementById('RoomCode').value) {
                        window_innerTxt('RoomCode_tips', '房间密码不能为空')
                    } else {
                        //在这里判断密码是否正确,下面为进入后
                        //ux,最后一个参数说明，90为单个用户的宽度，用户的个数*90等于总长度
                        ux('', '', '-60px', '120px', 90 * 6 + 'px');
                        set_p('success_after_btn', 'p', '60px');
                        //显示房间信息
                        window_innerTxt('Room_info','我是房间信息')
                    }
                }
                break;
        }
    }
}
document.getElementById("Modal_close_btn").onclick = function () {
    set_style('Modal','left','')
}
document.getElementById("bullet_close_btn").onclick = function () {
    set_style('bullet','left','')
}
document.getElementById('Send_btn').onclick = function () {
    set_style('bullet','left','0px')

}
//发送弹幕按钮
document.getElementById('bullet_meeting_button').onclick = function(){
    if(document.getElementById('bullet_input').value){
        bullet_txt('test',document.getElementById('bullet_input').value,'');
        set_style('bullet','left','');
        document.getElementById('bullet_input').value = '';
    }else{
        window_innerTxt('bullet_tips','发送内容不能为空')
    }
}
//退出按钮
document.getElementById('out_btn').onclick = function () {
    ux('', '', '', '', 90 * 6 + 'px');
    set_p('success_after_btn', 'p', '0px');
    window_innerTxt('message_box','')
    window_innerTxt('Room_info','')
}


//id：元素id
//boolean:标志位
//fun1:为真执行的函数
//fun2:为假执行的函数
function Common_btn(id,boolean,fun1,fun2){
    let dom = document.getElementById(id);
    let state = boolean;
    dom.onclick = function(){
        state = !state;
        if(state){
            fun1();
        }else{
            fun2();
        }
    }
}

//切换前置/后置摄像头按钮
Common_btn('switching_camera',false,()=>{
    console.log('打开前置摄像头');
},()=>{
    console.log('打开后置摄像头')
})

//打开/关闭麦克风按钮
Common_btn('Microphone_btn',false,()=>{
    set_style('Microphone_btn','background','#fff');
    set_style('Microphone_btn','color','#666');
    //打开麦克风
},()=>{
    set_style('Microphone_btn','background','');
    set_style('Microphone_btn','color','');
    //关闭麦克风
})

//打开/关闭视频按钮
Common_btn('Video_btn',false,()=>{
    set_style('Video_btn','background','#fff');
    set_style('Video_btn','color','#666');
    //打开视频
},()=>{
    set_style('Video_btn','background','');
    set_style('Video_btn','color','');
    //打开视频
})

//打开/关闭共享屏幕
Common_btn('Screen_sharing_btn',false,()=>{
    set_style('Screen_sharing_btn','background','#fff');
    set_style('Screen_sharing_btn','color','#666');
    //打开视频
},()=>{
    set_style('Screen_sharing_btn','background','');
    set_style('Screen_sharing_btn','color','');
    //关闭视频
})

//点击视频
// Common_btn('play',true,()=>{
//     //set_style('Screen_sharing_btn','background','');
//     alert('1')
// },()=>{
//     alert('2')
// })
